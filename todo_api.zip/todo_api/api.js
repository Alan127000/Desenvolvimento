const express = require('express')
const cors = require('cors')
const tasks = require('./mocks/tasks.json')
const fs = require('fs')

const app = express()

app.use(cors())
app.use(express.urlencoded({ extended: false }))
app.use(express.json())

app.post('/tasks', (req, res) => {
    const { body: { todo, description } } = req
    const lastTask = tasks[tasks.length - 1]

    if (!description) {
        res.json({ message: 'Missing description.' }).status(400).send()
    }

    const task = {
        id: lastTask?.id + 1 || 1,
        todo: todo || false,
        created_at: new Date(),
        description
    }

    tasks.push(task)
    fs.writeFileSync('./mocks/tasks.json', JSON.stringify(tasks))

    res.json(task).status(201).send()
})

app.get('/tasks', (req, res) => {
    const { query: { todo } } = req

    const condition = todo === 'true'

    const allTasks = typeof todo === 'string'
        ? tasks.filter(t => t.todo == condition)
        : tasks

    const sorted = allTasks.sort((a, b) => new Date(a.created_at) - new Date(b.created_at))

    res.json(sorted).status(200).send()
})

app.get('/tasks/:task_id', (req, res) => {
    const { params: { task_id } } = req

    const task = tasks.find(t => t.id == task_id)

    res.json(task).status(200).send()
})

app.put('/tasks/:task_id/status', (req, res) => {
    const { params: { task_id }, body: { todo } } = req

    const task = tasks.find(t => t.id == task_id)
    task.todo = todo
    fs.writeFileSync('./mocks/tasks.json', JSON.stringify(tasks))

    res.status(204).send()
})

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000')
})